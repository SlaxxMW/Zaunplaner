# Arbeitszeiterfassung PWA (v1.4.0)

- Offline nutzbar (PWA) + GitHub Pages kompatibel
- Datenhaltung: IndexedDB (bleibt bei Updates erhalten)
- Feiertage nach Bundesland (Default: Bayern, Mariä Himmelfahrt aktiv)

## Start (lokal)
Einfach über einen lokalen Webserver öffnen (nicht per Datei-Doppelklick), z.B. mit VS Code Live Server oder Python.

## GitHub Pages
Repository erstellen → Dateien hochladen → Settings → Pages → Deploy from branch.

## Export/Import
Einstellungen → Export/Import (CSV / PDF / Backup JSON)
